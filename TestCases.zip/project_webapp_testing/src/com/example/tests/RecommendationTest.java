package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class RecommendationTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "lib\\win\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testSignInWithValidCredentials() throws Exception {
        driver.get("http://ec2-3-16-149-43.us-east-2.compute.amazonaws.com:8080/signup/index.jsp");
        Thread.sleep(1000);
        
        driver.findElement(By.id("username")).sendKeys("John Doe");
        Thread.sleep(500);
        
        driver.findElement(By.id("password")).sendKeys("12345");
        Thread.sleep(500);
        
        driver.findElement(By.id("signin")).click();
        Thread.sleep(500);
        
        driver.findElement(By.xpath("//a[@id='Recommendation']")).click();
        Thread.sleep(1000);

        String message = driver.findElement(By.xpath("//h2[@class='bg-success text-center text-light card-header']")).getText();
        assertEquals("Meal Recommendations", message);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}