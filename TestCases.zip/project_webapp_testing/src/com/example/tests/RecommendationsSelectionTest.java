package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class RecommendationsSelectionTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "lib\\win\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testSignInWithValidCredentials() throws Exception {
        driver.get("http://ec2-3-16-149-43.us-east-2.compute.amazonaws.com:8080/signup/calorieIntake.html");
        Thread.sleep(1000);

        WebElement dropdownElement = driver.findElement(By.name("meal"));
        Select dropdown = new Select(dropdownElement);
        dropdown.selectByVisibleText("Select");
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(1000);
        
        String message = driver.findElement(By.xpath("//h2[@style='color: white;']")).getText();
        assertEquals("Meal Options:", message);
        
        
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}