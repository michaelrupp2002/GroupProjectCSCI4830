package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class DailyTrackingSelectionSelectTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "lib\\win\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testSignInWithValidCredentials() throws Exception {
        driver.get("http://ec2-3-16-149-43.us-east-2.compute.amazonaws.com:8080/signup/dailyTracking?meal=morning");
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//input[@value='Reset Total Calories']")).click();
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//input[@value='Add to Total Calories']")).click();
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//input[@value='Add to Total Calories']")).click();
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//input[@value='Add to Total Calories']")).click();
        Thread.sleep(1000);
        
        String message = driver.findElement(By.xpath("//h2[@style='font-size: 28px; color: white;']")).getText();
        assertEquals("Recommended Calorie Intake Range in Breakfast: 200-400 calories", message);
        
        
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}