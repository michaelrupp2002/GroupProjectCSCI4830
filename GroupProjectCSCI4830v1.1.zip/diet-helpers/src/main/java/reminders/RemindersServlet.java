package reminders;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;

@WebServlet("/Reminders")
public class RemindersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String JDBC_URL = "jdbc:mysql://ec2-3-16-149-43.us-east-2.compute.amazonaws.com:3306/UserData";
    private static final String JDBC_USER = "diethelper_remote";
    private static final String JDBC_PASSWORD = "diethelper";

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Process form submission
    	String username = (String) request.getSession().getAttribute("name");
    	if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String[] remindersKeys = {"DrinkWater", "Eatmeal", "BrushTeeth", "Steps", "Exercise"};
        Map<String, Integer> remindersMap = new HashMap<>();
        for (String key : remindersKeys) {
            String value = request.getParameter(key);
            if (value != null && value.equals("1")) {
                remindersMap.put(key, 1);
            } else {
                remindersMap.put(key, 0); // Mark as unchecked
            }
        }

        // Store data in the database
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String insertQuery = "INSERT INTO remindersData (username, DrinkWater, Eatmeal, BrushTeeth, Steps, Exercise) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(insertQuery)) {
                statement.setString(1, username);
                for (int i = 0; i < remindersKeys.length; i++) {
                    statement.setInt(i + 2, remindersMap.get(remindersKeys[i]));
                }
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions
        }

        // Redirect back to the page
        response.sendRedirect(request.getContextPath() + "/Reminders");
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("name");
        if (username == null) {
            // Handle case where username is not found in session
            response.sendRedirect("login.jsp");
            return;
        }

        // Database connection details
        Connection connection = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // Check if a previous entry exists for the username
            String selectQuery = "SELECT * FROM remindersData WHERE username = ? ORDER BY id DESC LIMIT 1";
            try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {
                statement.setString(1, username);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    // Existing entry found, populate form with existing values
                    out.println("<html><head><title>Reminders</title></head><body>");
                    out.println("<h2>Reminders for Today</h2>");
                    out.println("<form method='post'>");
                    out.println("<input type='hidden' name='username' value='" + username + "'>"); // To submit the form with the username
                    out.println("<input type='checkbox' name='DrinkWater' value='1' " + (resultSet.getInt("DrinkWater") == 1 ? "checked" : "") + "> Drink Water<br>");
                    out.println("<input type='checkbox' name='Eatmeal' value='1' " + (resultSet.getInt("Eatmeal") == 1 ? "checked" : "") + "> Eat Meal<br>");
                    out.println("<input type='checkbox' name='BrushTeeth' value='1' " + (resultSet.getInt("BrushTeeth") == 1 ? "checked" : "") + "> Brush Teeth<br>");
                    out.println("<input type='checkbox' name='Steps' value='1' " + (resultSet.getInt("Steps") == 1 ? "checked" : "") + "> Take 10,000 Steps<br>");
                    out.println("<input type='checkbox' name='Exercise' value='1' " + (resultSet.getInt("Exercise") == 1 ? "checked" : "") + "> Exercise<br>");
                    out.println("<input type='submit' value='Submit'>");
                    out.println("</form>");
                    out.println("</body></html>");
                } else {
                    // No existing entry found, display empty form
                    out.println("<html><head><title>Reminders</title></head><body>");
                    out.println("<h2>Reminders for Today</h2>");
                    out.println("<form method='post'>");
                    out.println("<input type='hidden' name='username' value='" + username + "'>"); // To submit the form with the username
                    out.println("<input type='checkbox' name='DrinkWater' value='1'> Drink Water<br>");
                    out.println("<input type='checkbox' name='Eatmeal' value='1'> Eat Meal<br>");
                    out.println("<input type='checkbox' name='BrushTeeth' value='1'> Brush Teeth<br>");
                    out.println("<input type='checkbox' name='Steps' value='1'> Take 10,000 Steps<br>");
                    out.println("<input type='checkbox' name='Exercise' value='1'> Exercise<br>");
                    out.println("<input type='submit' value='Submit'>");
                    out.println("</form>");
                    out.println("</body></html>");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}